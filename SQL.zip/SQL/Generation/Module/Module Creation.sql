INSERT INTO Module (ModuleCode, Name, Description, OnlineResources)
VALUES
('PRG281', 'Programming 281', 'Advanced Programming course', 'www.stackoverflow.com'),
('PRG282', 'Programming 282', 'Continuation of PRG282', 'www.stackoverflow'),
('DBD281', 'Database Development', 'Advanced Database course', 'w3schools.com/sql/'),
('IOT281', 'Internet Of Things', 'Course on the Internet of Things', 'www.google.com'),
('INF281', 'Information Systems', 'Course on Information Systems', 'www.google.com'),
('STA282', 'Statistics', 'Course on Statistics', 'www.google.com'),
('MAT281', 'Mathematics', 'Course on Mathematics', 'calculator.com'),
('PRG251', 'Programming 251', 'The same as PRG281', 'www.stackoverflow.com'),
('PRG252', 'Programming 252', 'The same as PRG282', 'www.stackoverflow.com'),
('DBD251', 'Database Development', 'Advanced Database course', 'w3schools.com/sql/'),
('IOT251', 'Internet of Things', 'Advanced course on IOT', 'www.google.com'),
('INF251', 'Information Systems', 'Advanced course on Information Systems', 'www.google.com'),
('STA251', 'Statistics', 'Advanced course on Statistics', 'www.google.com'),
('MAT251', 'Mathematics', 'Advanced course on Mathematics', 'calculator.com')