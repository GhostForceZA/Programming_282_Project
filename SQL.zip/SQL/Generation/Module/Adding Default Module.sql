INSERT INTO Module
VALUES ('DF101', 'Default', 'Default module', '')