use StudentInfo

GO

INSERT INTO Student (StudentNumber, Name, Surname, DOB, Gender, Phone, Address)
VALUES
(
		'Er6',
		'Ivor',
		'Everett',
		'1987-09-13',
		'M',
		'0845 46 43',
		'712-1903 Vitae, St.'
	),
	(
		'Mn3',
		'Fulton',
		'Myers',
		'1985-12-31',
		'M',
		'0800 1111',
		'6905 Pellentesque Rd.'
	),
	(
		'Oy7',
		'Bradley',
		'Oneil',
		'1999-05-25',
		'M',
		'024765058',
		'601-4597 Congue. St.'
	),
	(
		'Mn0',
		'Shannon',
		'Malone',
		'1988-02-12',
		'F',
		'0720 5621',
		'778-2818 Ultrices Ave'
	),
	(
		'Ct1',
		'Amethyst',
		'Callahan',
		'1993-08-15',
		'F',
		'01548 817',
		'8789 Augue Rd.'
	),
	(
		'Fc5',
		'Eric',
		'Fuller',
		'1997-10-20',
		'M',
		'03 3652687',
		'1350 Natoque Road'
	),
	(
		'Bh8',
		'Marah',
		'Brooks',
		'1987-05-22',
		'F',
		'0167 5981',
		'7144 Sed Avenue'
	),
	(
		'Kr4',
		'Baxter',
		'Kent',
		'2000-09-16',
		'M',
		'011 290 83',
		'213-6042 Dignissim. St.'
	),
	(
		'De8',
		'Chloe',
		'Dodson',
		'1983-04-19',
		'F',
		'03 303 272',
		'6671 Phasellus Ave'
	),
	(
		'Ay2',
		'Cassady',
		'Aguirre',
		'1990-02-06',
		'F',
		'08 917 72',
		'107-4447 Dui, Street'
	),
	(
		'Dn6',
		'Harrison',
		'Durham',
		'1989-11-11',
		'M',
		'080 533 67',
		'522-9008 Justo Rd.'
	),
	(
		'Ro0',
		'Cleo',
		'Roberson',
		'1998-06-29',
		'F',
		'014 6134',
		'P.O. Box 506, 8991 Sed Road'
	),
	(
		'Be3',
		'Reece',
		'Bradley',
		'1998-09-19',
		'M',
		'01 336 618',
		'Ap #279-8062 Donec Rd.'
	),
	(
		'Cn3',
		'Harrison',
		'Curry',
		'1986-02-28',
		'M',
		'056 44 382',
		'Ap #615-3217 Leo, Rd.'
	),
	(
		'Mz9',
		'Inez',
		'Mays',
		'1991-01-04',
		'F',
		'056 94 851',
		'Ap #836-8016 Accumsan St.'
	),
	(
		'My7',
		'Shelley',
		'Murphy',
		'1992-05-19',
		'F',
		'076 537 23',
		'P.O. Box 474, 7024 Dictum St.'
	),
	(
		'Sa5',
		'Melinda',
		'Short',
		'1989-04-21',
		'F',
		'056 43 018',
		'354-428 Ut St.'
	),
	(
		'Sl4',
		'Uriel',
		'Soto',
		'1992-12-30',
		'F',
		'025 268 32',
		'P.O. Box 508, 2986 Ut Road'
	),
	(
		'Bn8',
		'Raven',
		'Burris',
		'1981-09-30',
		'F',
		'011 314 81',
		'6467 Aliquam Av.'
	),
	(
		'Kr0',
		'Piper',
		'Kennedy',
		'1991-12-25',
		'M',
		'074 715',
		'P.O. Box 209, 1942 Donec Av.'
	)
	