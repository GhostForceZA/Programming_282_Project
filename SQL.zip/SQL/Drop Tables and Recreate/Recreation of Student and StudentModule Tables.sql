USE StudentInfo
DROP TABLE Student
DROP TABLE StudentModule

GO

CREATE TABLE Student 
(
	StudentNumber VARCHAR(20) PRIMARY KEY,
	Name VARCHAR(10) NOT NULL,
	Surname VARCHAR(10) NOT NULL,
	StudentImage IMAGE NULL,
	DOB Date,
	Gender VARCHAR(10),
	Phone VARCHAR(11),
	Address VARCHAR(60)
)

CREATE TABLE StudentModule
(
	StudentNumber VARCHAR(20) References Student(StudentNumber),
	ModuleCode VARCHAR(10) References Module(ModuleCode)
)